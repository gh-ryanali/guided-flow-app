import React from 'react'

export function Button({ className = '', variant = 'default', disabled = false, children, ...props }) {
  return (
    <button className={`button ${variant === 'outline' ? 'button-outline' : ''} ${className}`} disabled={disabled} {...props}>
      {children}
    </button>
  )
}
